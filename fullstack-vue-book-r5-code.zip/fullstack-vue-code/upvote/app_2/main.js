new Vue({
  el: '#app',
  data: {
    submissions: Seed.submissions 
  }
});
