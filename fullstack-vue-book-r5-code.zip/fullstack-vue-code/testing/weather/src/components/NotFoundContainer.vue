<template>
  <h1 class="subtitle is-size-3">Sorry, this route does not exist :(</h1>
</template>

<script>
export default {
  name: 'NotFoundContainer',
}
</script>
