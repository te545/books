import App from '@/App';

describe('App.vue', () => {

});
