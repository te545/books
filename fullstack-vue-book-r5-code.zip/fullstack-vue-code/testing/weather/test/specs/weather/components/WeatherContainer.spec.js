import WeatherContainer from '@/components/WeatherContainer';

describe('WeatherContainer.vue', () => {
  
});
