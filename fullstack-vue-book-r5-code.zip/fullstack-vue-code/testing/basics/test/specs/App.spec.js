import Vue from 'vue';
import App from '@/App';

describe('App.vue', () => {
  it('should run this dummy test', () => {
     expect('Dummy' + ' Test!').to.equal('Dummy Test!');
  });
});
