import React from 'react';
import createReactClass from 'create-react-class';

// React.createClass
const CreateClassApp = createReactClass({
  render: function() {} // required method
});

export default CreateClassApp;
