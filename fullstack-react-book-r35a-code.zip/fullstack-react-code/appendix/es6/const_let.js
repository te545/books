var myVariable = 5;
