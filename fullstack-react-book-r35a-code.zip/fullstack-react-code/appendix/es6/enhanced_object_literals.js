const getState = () => {};
const dispatch = () => {};

const explicit = {
  getState: getState,
  dispatch: dispatch,
};

const implicit = {
  getState,
  dispatch,
};
